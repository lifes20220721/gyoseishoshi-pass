'use strict';

window.GYOPASS_SUBSCRIPTION_CONFIG = Object.freeze({
  enabled: true,
  packageName: 'com.gyoseishoshipass.app',
  verificationEndpoint: 'https://gyoseishoshi-pass-billing.gyosei-pass-85cbe232.workers.dev/v1/subscriptions/verify',
  freeQuestionCount: 100,
  totalQuestionCount: 1000,
  products: Object.freeze([
    Object.freeze({ id: 'gyosei_premium_monthly', label: '月額プラン', fallbackPrice: '月500円' }),
    Object.freeze({ id: 'gyosei_premium_yearly', label: '年額プラン', fallbackPrice: '年5,000円' })
  ])
});
